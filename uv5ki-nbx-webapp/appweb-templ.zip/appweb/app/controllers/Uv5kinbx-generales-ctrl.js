/** */
angular.module("Uv5kinbx")
.controller("uv5kiGeneralesCtrl", function($scope) {
	$scope.valor = "uv5kiGeneralesCtrl";
	$scope.pagina=0;
});


