/** */
angular.module("Uv5kinbx")
.controller("uv5kiGlobalCtrl", function($scope) {
	$scope.valor = "uv5kiGlobalCtrl";
	$scope.pagina=0;
});


